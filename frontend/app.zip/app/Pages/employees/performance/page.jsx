import React from "react";

const page = () => {
  return <div>THIS IS THE PERFORMANCE PAGE 💬</div>;
};

export default page;
