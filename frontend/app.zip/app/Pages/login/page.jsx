import React from "react";
import LoginPage from "../../component/Login";

const page = () => {
  return (
    <div>
      <LoginPage />
    </div>
  );
};

export default page;
