import LoginForm from "./component/Login";

export default function Home() {
  return (
    <div>
      <LoginForm />
    </div>
  );
}
